THE OCCASION EDIT - DRAFT LEGAL DOCUMENT PACK

Files included:
1. Terms and Conditions
2. Privacy Policy
3. Cookie Policy
4. Website Terms of Use
5. Booking Form and Service Agreement
6. Customer GDPR Privacy Notice

ACTION BEFORE PUBLICATION
- Replace every [INSERT ...] field.
- Confirm the legal entity, address, contact information, VAT/company details and ICO registration status.
- Run a cookie scan and list the exact cookies and suppliers.
- Confirm actual retention periods, processors, international transfers and security practices.
- Choose a fair cancellation scale based on likely direct loss, not a penalty.
- Have a UK solicitor review the final documents, particularly cancellation rights, personalised goods, liability, subcontracting, outdoor installations and business-customer bookings.

Drafted from official CMA/GOV.UK and ICO small-business guidance current at 28 October 2026.
